-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2018 at 12:06 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `register`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(5) NOT NULL,
  `appointment_doctor` int(30) NOT NULL,
  `appointment_patient` int(30) NOT NULL,
  `appointment_time` time NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_available` varchar(3) NOT NULL DEFAULT 'YES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `appointment_doctor`, `appointment_patient`, `appointment_time`, `appointment_date`, `appointment_available`) VALUES
(1, 8, 9, '21:34:00', '2018-07-08', 'YES'),
(2, 9, 10, '00:12:00', '2018-12-07', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `delete_appointment`
--

CREATE TABLE `delete_appointment` (
  `appointment_id` int(5) NOT NULL,
  `appointment_doctor` int(30) NOT NULL,
  `appointment_patient` int(30) NOT NULL,
  `appointment_time` time NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_available` varchar(3) NOT NULL DEFAULT 'YES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delete_appointment`
--

INSERT INTO `delete_appointment` (`appointment_id`, `appointment_doctor`, `appointment_patient`, `appointment_time`, `appointment_date`, `appointment_available`) VALUES
(3, 10, 11, '18:59:00', '2018-07-25', 'YES'),
(4, 12, 11, '21:34:00', '2018-08-07', 'YES'),
(5, 12, 9, '09:34:00', '2018-08-07', 'YES'),
(6, 12, 10, '21:34:00', '2018-08-07', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(5) NOT NULL,
  `doctor_name` varchar(30) NOT NULL,
  `doctor_spec` varchar(30) NOT NULL,
  `doctor_available` varchar(3) NOT NULL DEFAULT 'YES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `doctor_name`, `doctor_spec`, `doctor_available`) VALUES
(7, 'Dr. Aziz Khan', 'EyeExpert', 'NOT'),
(8, 'Dr.Arif hasan', 'HeartExpert', 'YES'),
(9, 'Dr.Mohammad Ali', 'Body', 'NOT'),
(10, 'Dr. Sammi Akhter', 'KidneyExpert', 'YES'),
(11, 'Dr. Syed Atiqul Haq  physician', '  physician', 'YES'),
(14, 'Dr. Syed Atiqul Haq  ', 'physicianExpert', 'YES'),
(15, ' mahbub', 'HeartExpert', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(5) NOT NULL,
  `patient_name` varchar(30) NOT NULL,
  `patient_address` varchar(30) NOT NULL,
  `patient_gender` varchar(6) NOT NULL,
  `patient_available` varchar(3) NOT NULL DEFAULT 'YES'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `patient_name`, `patient_address`, `patient_gender`, `patient_available`) VALUES
(9, ' mahbub Hasan', 'mirpur11', 'male', 'YES'),
(10, 'Arif', 'Dhanmondi', 'male', 'YES'),
(11, 'Rifa', 'mirpur12', 'female', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `trn_date`) VALUES
(5, 'admin', 'nabiharifa@gmail.com', 'ada2673aa8bf25d81d5bdd727d8a1e8c', '2018-07-26 14:13:54'),
(6, 'Mahbub', 'mahbubdhruba100@gmail.com', '4c79658effc8d6ad5fe4b1e0865e1277', '2018-07-26 16:13:59'),
(7, 'Arif', 'arif@gmail.com', '0ff6c3ace16359e41e37d40b8301d67f', '2018-07-26 16:20:49'),
(8, 'Dhruba', 'dhrubakoli@gmail.com', 'ada2673aa8bf25d81d5bdd727d8a1e8c', '2018-07-26 17:05:43'),
(9, 'df', 'sabbir12@gmail.com', '75819783c5ad99efaec29d8a7570da51', '2018-07-27 07:56:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `delete_appointment`
--
ALTER TABLE `delete_appointment`
  ADD PRIMARY KEY (`appointment_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `doctor_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patient_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
